#pragma once
struct Collision {
    bool collides;
    bool damages;
    SDL_Rect intersection; // Rect�ngulo de intersecci�n para ajustes

    operator bool() const { return collides; }
};