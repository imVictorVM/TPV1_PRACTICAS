#include "checkML.h"
#include "Koopa.h"
#include "Game.h"

using namespace std;

Koopa::Koopa(Game* game, stringstream& atributes) : position(), koopaTexture(game->getTexture(Game::KOOPA)), game(game), frameRunner(0), frozen(true), previousOffset(0)
{
	string line;

	getline(atributes, line);

	stringstream lineStream(line);

	int posX, posY;
	lineStream >> posX;
	lineStream >> posY;

	position = Vector2D<int>((posX-1) * Game::TILE_SIDE, (posY-1)* Game::TILE_SIDE);
	direction = Vector2D<int>(-1, 0);

}

void
Koopa::render() const {

	if (frozen) {
		//posici�n del koopa
		SDL_Rect KPosition;
		KPosition.x = position.getX();
		KPosition.y = position.getY();
		KPosition.w = Game::TILE_SIDE;
		KPosition.h = Game::TILE_SIDE;

		int frame = 0;
		//movimiento del koopa
		if (frameRunner == 0) frame = 0;
		if (frameRunner == 1) frame = 1;
		if (frameRunner == 2) frame = 2;
		if (frameRunner == 3) frame = 3;


		//Renderizamos con los parametros actualizados
		koopaTexture->renderFrame(KPosition, 0, frame);
	}
}


void
Koopa::update() {



	//Los goombas se mueven en funcion el offset del mapa
	int newOffset = game->getMapOffset();
	int offsetChange = newOffset - previousOffset;
	if (offsetChange != 0) {
		position = Vector2D<int>(position.getX() - offsetChange, position.getY());
		previousOffset = newOffset;
	}

	if (frozen) {
		position = position + direction;
		if (frameRunner > 3) frameRunner = 0;
		frameRunner++;
	}
}

//Collision
//hit(const SDL_Rect rect, bool fromPlayer) {
//
//}